#include <stdlib.h>

int main() {
  system("C:\\Windows\\System32\\cmd.exe");
}
